from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('admin_login/', views.admin_login, name='admin_login'),
    path('patient_login/', views.patient_login, name='patient_login'),
    path('donor_login/', views.donor_login, name='donor_login'),
    path('patient_register/', views.patient_register, name='patient_register'),
    path('donor_register/', views.donor_register, name='donor_register'),
    path('patient_dashboard/', views.patient_dashboard, name='patient_dashboard'),
    path('admin_dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('donor_dashboard/', views.donor_dashboard, name='donor_dashboard'),
    path('patient_request_blood/', views.patient_request_blood, name='patient_request_blood'),
    path('logout_patient/', views.patient_logout, name='logout_patient'),
    path('logout_admin/', views.admin_logout, name='logout_admin'),
    path('donor_logout/', views.donor_logout, name='donor_logout'),
    path('admin_logout/', views.admin_logout, name='admin_logout'),
    
 

]
