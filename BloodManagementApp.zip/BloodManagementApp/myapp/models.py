from django.db import models
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError

# Helper function to validate age
def validate_age(value):
    if value < 18 or value > 120:
        raise ValidationError('Age must be between 18 and 120.')

# Patient model
class Patient(models.Model):
    user = models.OneToOneField(
        User, 
        on_delete=models.CASCADE, 
        related_name='patient',
        help_text="Link to the corresponding user account."
    )
    blood_type = models.CharField(
        max_length=3,
        choices=[
            ('A+', 'A+'), ('A-', 'A-'), 
            ('B+', 'B+'), ('B-', 'B-'), 
            ('AB+', 'AB+'), ('AB-', 'AB-'), 
            ('O+', 'O+'), ('O-', 'O-')
        ],
        help_text="Patient's blood group."
    )
    contact_number = models.CharField(
        max_length=15, 
        help_text="Patient's contact number."
    )
    address = models.TextField(
        blank=True, 
        null=True, 
        help_text="Patient's residential address."
    )
    age = models.IntegerField(
        validators=[validate_age], 
        help_text="Patient's age, must be between 18 and 120."
    )
    date_of_birth = models.DateField(
        null=True, 
        blank=True, 
        help_text="Patient's date of birth."
    )
    gender = models.CharField(
        max_length=10,
        choices=[('Male', 'Male'), ('Female', 'Female'), ('Other', 'Other')],
        null=True, 
        blank=True, 
        help_text="Patient's gender."
    )

    def __str__(self):
        # Improved string representation for better display in admin interface
        return f"{self.user.get_full_name()} ({self.user.username})" if self.user.get_full_name() else f"Unnamed Patient ({self.user.username})"

    class Meta:
        verbose_name = 'Patient'
        verbose_name_plural = 'Patients'

# Donor model
class Donor(models.Model):
    user = models.OneToOneField(
        User, 
        on_delete=models.CASCADE, 
        related_name='donor',
        help_text="Link to the corresponding user account."
    )
    blood_type = models.CharField(
        max_length=3,
        choices=[
            ('A+', 'A+'), ('A-', 'A-'), 
            ('B+', 'B+'), ('B-', 'B-'), 
            ('AB+', 'AB+'), ('AB-', 'AB-'), 
            ('O+', 'O+'), ('O-', 'O-')
        ],
        help_text="Donor's blood group."
    )
    contact_number = models.CharField(
        max_length=15, 
        help_text="Donor's contact number."
    )
    address = models.TextField(
        blank=True, 
        null=True, 
        help_text="Donor's residential address."
    )
    age = models.IntegerField(
        validators=[validate_age], 
        help_text="Donor's age, must be between 18 and 120."
    )
    donation_date = models.DateField(
        null=True, 
        blank=True, 
        help_text="Date of the last donation."
    )

    def __str__(self):
        # Improved string representation for better display in admin interface
        return f"{self.user.get_full_name()} ({self.user.username})" if self.user.get_full_name() else f"Unnamed Donor ({self.user.username})"

    class Meta:
        verbose_name = 'Donor'
        verbose_name_plural = 'Donors'

# PatientRequest model
class PatientRequest(models.Model):
    patient_name = models.CharField(max_length=100, default='Default Patient')
    blood_type = models.CharField(
        max_length=3,
        choices=[
            ('A+', 'A+'), ('A-', 'A-'), 
            ('B+', 'B+'), ('B-', 'B-'), 
            ('AB+', 'AB+'), ('AB-', 'AB-'), 
            ('O+', 'O+'), ('O-', 'O-')
        ],
        help_text="Blood type requested."
    )
    contact_number = models.CharField(
        max_length=15, 
        help_text="Contact number of the patient or requester."
    )
    status = models.CharField(
        max_length=20,
        choices=[
            ('pending', 'Pending'), 
            ('approved', 'Approved'), 
            ('rejected', 'Rejected')
        ],
        default='pending',
        help_text="Current status of the blood request."
    )
    created_at = models.DateTimeField(
        auto_now_add=True, 
        help_text="Time when the request was created."
    )

    def __str__(self):
        # Improved string representation for better display in admin interface
        return f"Request by {self.patient_name} for {self.blood_type} blood"

    class Meta:
        verbose_name = 'Patient Request'
        verbose_name_plural = 'Patient Requests'
        ordering = ['-created_at']  # Orders requests by most recent first
