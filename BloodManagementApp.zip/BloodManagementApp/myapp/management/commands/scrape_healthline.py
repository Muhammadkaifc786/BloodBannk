import requests
from bs4 import BeautifulSoup

# URL to scrape
url = 'https://www.healthline.com'  # Replace this with the actual URL if needed

# Send a GET request to the webpage
response = requests.get(url)
soup = BeautifulSoup(response.content, 'html.parser')

# Find the section containing the "THIS JUST IN" items
just_in_section = soup.find('div', {'id': 'this-just-in'})

# Extract the list items
items = just_in_section.find_all('li', {'class': 'css-1ib8oek'})

# Loop through each item to extract title, description, and image URL
for item in items:
    # Extract title (anchor tag inside <div> with class "css-1yf5qft")
    title = item.find('a', {'class': 'css-1yf5qft'}).text.strip()

    # Extract description (paragraph tag with class "css-ghc6ug")
    description = item.find('p', {'class': 'css-ghc6ug'}).text.strip()

    # Extract image URL (inside <img> tag inside <lazy-image> tag)
    img_tag = item.find('img')
    img_url = img_tag['src'] if img_tag else None

    # Print the extracted data
    print(f"Title: {title}")
    print(f"Description: {description}")
    print(f"Image URL: {img_url}")
    print("=" * 50)  # Separator for readability
