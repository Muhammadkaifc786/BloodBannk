from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.contrib import messages
from django.http import HttpResponseRedirect
from .models import  Patient, Donor, PatientRequest

from . import forms
from django.db import models

# Home view
def home(request):
    return render(request, 'myapp/home.html')

# Admin login view
def admin_login(request):
    return custom_login(request, 'admin', 'admin_login', 'admin_dashboard', 'is_staff')

# Patient login view
def patient_login(request):
    return custom_login(request, 'patient', 'patient_login', 'patient_dashboard', 'patient')




# Donor login view
def donor_login(request):
    return custom_login(request, 'donor', 'donor_login', 'donor_dashboard', 'donor')

# Custom login function for multiple user types
def custom_login(request, user_type, template_name, redirect_view, check_attr):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)

        if user is not None:
            if hasattr(user, check_attr):
                login(request, user)
                messages.success(request, f'{user_type.capitalize()} login successful!')
                return redirect(redirect_view)
            else:
                messages.error(request, f'User is not a valid {user_type}.')
        else:
            messages.error(request, 'Invalid username or password.')
        return redirect(template_name)

    return render(request, f'myapp/{template_name}.html')

# Logout views
def custom_logout(request, user_type):
    logout(request)
    messages.success(request, f'You have logged out successfully.')
    return redirect('home')

def patient_logout(request):
    return custom_logout(request, 'patient')

def admin_logout(request):
    logout(request)
    return redirect('admin_login') 

def donor_logout(request):
    logout(request)  # Logs out the user
    return redirect('/')
# Donor registration view
def donor_register(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')
        blood_type = request.POST.get('blood_type')
        contact_number = request.POST.get('contact_number')
        address = request.POST.get('address', '')  # Optional field
        age = request.POST.get('age')

        if not confirm_password or password != confirm_password:
            messages.error(request, 'Passwords do not match.')
        elif User.objects.filter(username=username).exists():
            messages.error(request, 'Username already exists.')
        elif int(age) < 18:
            messages.error(request, 'Age must be 18 or older.')
        else:
            user = User.objects.create_user(username=username, password=password, email=email)
            Donor.objects.create(
                user=user,
                blood_type=blood_type,
                contact_number=contact_number,
                address=address,
                age=age
            )
            messages.success(request, 'Registration successful! Please log in.')
            return redirect('donor_login')

    return render(request, 'myapp/donor_register.html')

# Patient registration view
def patient_register(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')
        blood_type = request.POST.get('blood_type')
        contact_number = request.POST.get('contact_number')
        address = request.POST.get('address', '')  # Optional field
        age = request.POST.get('age')

        if not confirm_password or password != confirm_password:
            messages.error(request, 'Passwords do not match.')
        elif User.objects.filter(username=username).exists():
            messages.error(request, 'Username already exists.')
        elif int(age) < 18:
            messages.error(request, 'Age must be 18 or older.')
        else:
            user = User.objects.create_user(username=username, password=password, email=email)
            Patient.objects.create(
                user=user,
                blood_type=blood_type,
                contact_number=contact_number,
                address=address,
                age=age
            )
            messages.success(request, 'Registration successful! Please log in.')
            return redirect('patient_login')

    return render(request, 'myapp/patient_register.html')

# Donor dashboard view
def donor_dashboard(request):
    if request.user.is_authenticated and hasattr(request.user, 'donor'):
        blood_groups = Donor.objects.values('blood_type').annotate(count=models.Count('blood_type'))
        return render(request, 'myapp/donor_dashboard.html', {'blood_groups': blood_groups})
    else:
        messages.error(request, 'You are not authorized to access this page.')
        return redirect('home')

# Admin dashboard view
def admin_dashboard(request):
    if request.user.is_authenticated and request.user.is_staff:
        data = {
            'patients': Patient.objects.all(),
            'donors': Donor.objects.all()
        }
        return render(request, 'myapp/admin_dashboard.html', data)
    else:
        messages.error(request, 'You are not authorized to access this page.')
        return redirect('home')

# Patient dashboard view
def patient_dashboard(request):
    if request.user.is_authenticated and hasattr(request.user, 'patient'):
        data = {'patient': Patient.objects.get(user=request.user)}
        return render(request, 'myapp/patient_dashboard.html', data)
    else:
        messages.error(request, 'You are not authorized to access this page.')
        return redirect('home')

def logout_view(request):
    logout(request)
    messages.success(request, 'You have been logged out.')
    return redirect('home')




# Blood donation request view
def patient_request_blood(request):
    if request.method == 'POST':
        patient_name = request.POST.get('patient_name')
        blood_type = request.POST.get('blood_type')
        contact_number = request.POST.get('contact_number')
        request_status = request.POST.get('status')
        PatientRequest.objects.create(
            patient_name=patient_name,
            blood_type=blood_type,
            contact_number=contact_number,
            status=request_status
        )
        messages.success(request, 'Blood request submitted.')
        return redirect('patient_dashboard')
    
    return render(request, 'myapp/patient_request_blood.html')


